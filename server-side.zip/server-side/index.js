var http = require("http");
var WebSocketServer = require("websocket").server;
var MongoClient = require('mongodb').MongoClient
  , assert = require('assert');

// Database Connection
var url = 'mongodb://localhost:27017/castle';
var db, collection;
var clients = [];
MongoClient.connect(url, function(err, theDb) {
  assert.equal(null, err);
  console.log("Connected correctly to server");

  db = theDb;
  collection = db.collection('games');
});

var server = http.createServer(function (request, response) {});
server.listen(8080, "localhost");

var wServer = new WebSocketServer({httpServer : server});

setInterval(function () {

  var positions = []
  var xSign = 1, ySign = 1;
  for (i = 0; i < 2; i++) {

    if(Math.random() > 0.5) { xSign *= -1; }
    if(Math.random() > 0.5) { ySign *= -1; }

    xrand = (Math.floor(Math.random() * 750) - 550) * xSign ;
    zrand = (Math.floor(Math.random() * 750) - 550) * ySign ;

    positions.push([xrand, zrand]);
  }

  var villainData = {
    'name' : "villainSpawn",
    'positions' : positions
  };

  for(i in clients) {
    clients[i].sendUTF(JSON.stringify(villainData));
  }
}, 10000);

wServer.on('request', function (request) {
  var connection = request.accept(null, request.origin);
  clients.push(connection);

    var init = true;





  connection.on('message', function (message) {
    var parsed = JSON.parse(message['utf8Data']);
    //console.log(parsed);

    //if(init) {

    if(parsed['name'] == 'killInfo') {
      for (i in clients) {
        clients[i].sendUTF(JSON.stringify(parsed));
      }
    } else {

                       collection.update({ "gameName" : parsed['gameName'], "name" : parsed['name']}, parsed, {'upsert':true});

                  var cursor =collection.find( { "gameName": parsed['gameName'], "name": {"$ne" : parsed['name']} } );
                   cursor.each(function(err, doc) {
                      assert.equal(err, null);
                      if (doc != null) {
                         for (i in clients) {
                           clients[i].sendUTF(JSON.stringify(doc));
                         }


                      } else {
                         //console.log(" player "+parsed['name']+" not connected");
                      }

          });

        }
});

  connection.on('close', function (connection) {
    //console.log("closed");
  });

});
